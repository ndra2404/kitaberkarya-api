const sekolahModel = require('./sekolah.model');

module.exports={
    sekolahModel
};