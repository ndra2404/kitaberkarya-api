const sekolahController = require("./sekolah.controller");

//exportModul
module.exports = {
    sekolahController
}