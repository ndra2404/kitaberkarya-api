const string = require('./strings');
const response = require('./response');

module.exports = {string, response };