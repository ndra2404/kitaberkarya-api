var express = require('express');
var router = express.Router();

const { sekolahController } = require('./controllers');
router.get('/',sekolahController.get);
router.get('/detail/:id',sekolahController.getById);
router.post('/',sekolahController.addSekolah);

router.get('/sekolahtype',sekolahController.getType);

module.exports = router;